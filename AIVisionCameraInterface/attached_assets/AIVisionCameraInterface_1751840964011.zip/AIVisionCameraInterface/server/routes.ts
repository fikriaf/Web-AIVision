import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertModelConfigSchema, insertCaptureSchema, insertPerformanceMetricsSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import { promises as fs } from "fs";

const upload = multer({ dest: "uploads/" });

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time communication
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Store active WebSocket connections
  const activeConnections = new Set<WebSocket>();

  // Available model types with API integration
  const modelTypes = [
    {
      id: 'yolov8_local',
      name: 'YOLOv8 (Local)',
      description: 'Local object detection model',
      endpoint: '/api/detect/yolov8',
      requiresApiKey: false
    },
    {
      id: 'openai_vision',
      name: 'OpenAI Vision API',
      description: 'GPT-4 Vision for object detection',
      endpoint: 'https://api.openai.com/v1/chat/completions',
      requiresApiKey: true
    },
    {
      id: 'google_vision',
      name: 'Google Vision API',
      description: 'Google Cloud Vision API',
      endpoint: 'https://vision.googleapis.com/v1/images:annotate',
      requiresApiKey: true
    },
    {
      id: 'azure_vision',
      name: 'Azure Computer Vision',
      description: 'Microsoft Azure Vision API',
      endpoint: 'https://api.cognitive.microsoft.com/vision/v3.2/analyze',
      requiresApiKey: true
    },
    {
      id: 'custom_api',
      name: 'Custom API Endpoint',
      description: 'Your own AI model API',
      endpoint: '',
      requiresApiKey: false
    }
  ];

  wss.on('connection', (ws) => {
    console.log('New WebSocket connection established');
    activeConnections.add(ws);

    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        switch (data.type) {
          case 'camera_frame':
            // Handle camera frame for AI processing
            // Process frame with selected API
            const detections = await processFrameWithAPI(data.frameData, data.config);
            broadcast({
              type: 'ai_detection',
              detections,
              timestamp: Date.now()
            });
            break;
            
          case 'update_config':
            // Handle configuration updates
            const config = await storage.updateModelConfiguration(data.configId, data.config);
            broadcast({
              type: 'config_updated',
              config,
              timestamp: Date.now()
            });
            break;
            
          case 'test_api_connection':
            // Test API connection
            const testResult = await testAPIConnection(data.modelType, data.apiEndpoint, data.apiKey);
            ws.send(JSON.stringify({
              type: 'api_test_result',
              success: testResult.success,
              message: testResult.message,
              timestamp: Date.now()
            }));
            break;
            
          case 'request_metrics':
            // Send performance metrics
            const metrics = await storage.getLatestPerformanceMetrics();
            ws.send(JSON.stringify({
              type: 'performance_metrics',
              metrics,
              timestamp: Date.now()
            }));
            break;
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      console.log('WebSocket connection closed');
      activeConnections.delete(ws);
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      activeConnections.delete(ws);
    });
  });

  // Broadcast to all connected clients
  function broadcast(data: any) {
    const message = JSON.stringify(data);
    activeConnections.forEach((ws) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(message);
      }
    });
  }

  // Process frame with selected API
  async function processFrameWithAPI(frameData: string, config: any) {
    const modelType = modelTypes.find(m => m.id === config.modelType);
    
    if (!modelType) {
      return generateMockDetections();
    }

    try {
      switch (config.modelType) {
        case 'yolov8_local':
          return generateMockDetections(); // Local processing simulation
          
        case 'openai_vision':
          return await processWithOpenAI(frameData, config);
          
        case 'google_vision':
          return await processWithGoogleVision(frameData, config);
          
        case 'azure_vision':
          return await processWithAzureVision(frameData, config);
          
        case 'custom_api':
          return await processWithCustomAPI(frameData, config);
          
        default:
          return generateMockDetections();
      }
    } catch (error) {
      console.error('API processing error:', error);
      return generateMockDetections();
    }
  }

  // Test API connection
  async function testAPIConnection(modelType: string, apiEndpoint: string, apiKey: string) {
    try {
      switch (modelType) {
        case 'openai_vision':
          // Test OpenAI API
          const openaiResponse = await fetch('https://api.openai.com/v1/models', {
            headers: {
              'Authorization': `Bearer ${apiKey}`,
              'Content-Type': 'application/json'
            }
          });
          return {
            success: openaiResponse.ok,
            message: openaiResponse.ok ? 'OpenAI API connection successful' : 'Invalid API key or connection failed'
          };
          
        case 'google_vision':
          // Test Google Vision API
          const googleResponse = await fetch(`https://vision.googleapis.com/v1/images:annotate?key=${apiKey}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              requests: [{
                image: { content: 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/5+hHgAHggJ/PchI7wAAAABJRU5ErkJggg==' },
                features: [{ type: 'OBJECT_LOCALIZATION', maxResults: 1 }]
              }]
            })
          });
          return {
            success: googleResponse.ok,
            message: googleResponse.ok ? 'Google Vision API connection successful' : 'Invalid API key or connection failed'
          };
          
        case 'custom_api':
          // Test custom API endpoint
          if (!apiEndpoint) {
            return { success: false, message: 'Please provide API endpoint' };
          }
          const customResponse = await fetch(apiEndpoint, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              ...(apiKey && { 'Authorization': `Bearer ${apiKey}` })
            },
            body: JSON.stringify({ test: true })
          });
          return {
            success: customResponse.ok,
            message: customResponse.ok ? 'Custom API connection successful' : 'API endpoint connection failed'
          };
          
        default:
          return { success: true, message: 'Local model - no API connection needed' };
      }
    } catch (error) {
      return { success: false, message: `Connection error: ${error.message}` };
    }
  }

  // API processing functions
  async function processWithOpenAI(frameData: string, config: any) {
    // Simulate OpenAI Vision API processing
    await new Promise(resolve => setTimeout(resolve, 500));
    return generateMockDetections();
  }

  async function processWithGoogleVision(frameData: string, config: any) {
    // Simulate Google Vision API processing
    await new Promise(resolve => setTimeout(resolve, 300));
    return generateMockDetections();
  }

  async function processWithAzureVision(frameData: string, config: any) {
    // Simulate Azure Vision API processing
    await new Promise(resolve => setTimeout(resolve, 400));
    return generateMockDetections();
  }

  async function processWithCustomAPI(frameData: string, config: any) {
    // Simulate custom API processing
    await new Promise(resolve => setTimeout(resolve, 200));
    return generateMockDetections();
  }

  // Mock AI detection generator
  function generateMockDetections() {
    const classes = ['person', 'vehicle', 'animal', 'object'];
    const colors = ['#10b981', '#f59e0b', '#ef4444', '#3b82f6'];
    const detections = [];
    
    const numDetections = Math.floor(Math.random() * 4);
    for (let i = 0; i < numDetections; i++) {
      const classIndex = Math.floor(Math.random() * classes.length);
      detections.push({
        id: `det_${Date.now()}_${i}`,
        label: classes[classIndex],
        confidence: 0.7 + Math.random() * 0.3,
        bbox: {
          x: Math.random() * 0.6,
          y: Math.random() * 0.6,
          width: 0.1 + Math.random() * 0.3,
          height: 0.1 + Math.random() * 0.3,
        },
        color: colors[classIndex],
      });
    }
    
    return detections;
  }

  // Simulate performance metrics updates
  setInterval(async () => {
    const metrics = {
      fps: 28 + Math.random() * 4,
      latency: 40 + Math.random() * 20,
      memoryUsage: 2000 + Math.random() * 500,
      gpuUsage: 80 + Math.random() * 15,
      processingTime: 30 + Math.random() * 30,
    };
    
    await storage.createPerformanceMetrics(metrics);
    broadcast({
      type: 'performance_metrics',
      metrics,
      timestamp: Date.now()
    });
  }, 2000);

  // API Routes
  
  // Get available model types
  app.get('/api/model-types', async (req, res) => {
    try {
      res.json(modelTypes);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch model types' });
    }
  });

  // Test API connection
  app.post('/api/test-connection', async (req, res) => {
    try {
      const { modelType, apiEndpoint, apiKey } = req.body;
      const result = await testAPIConnection(modelType, apiEndpoint, apiKey);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: 'Failed to test connection' });
    }
  });
  
  // Get all AI models
  app.get('/api/models', async (req, res) => {
    try {
      const models = await storage.getAiModels();
      res.json(models);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch AI models' });
    }
  });

  // Get model configurations
  app.get('/api/configurations', async (req, res) => {
    try {
      const configs = await storage.getModelConfigurations();
      res.json(configs);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch configurations' });
    }
  });

  // Create or update model configuration
  app.post('/api/configurations', async (req, res) => {
    try {
      const validatedData = insertModelConfigSchema.parse(req.body);
      const config = await storage.createModelConfiguration(validatedData);
      res.json(config);
    } catch (error) {
      res.status(400).json({ error: 'Invalid configuration data' });
    }
  });

  // Update model configuration
  app.put('/api/configurations/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const config = await storage.updateModelConfiguration(id, updates);
      
      if (!config) {
        return res.status(404).json({ error: 'Configuration not found' });
      }
      
      res.json(config);
    } catch (error) {
      res.status(400).json({ error: 'Failed to update configuration' });
    }
  });

  // Get captures
  app.get('/api/captures', async (req, res) => {
    try {
      const captures = await storage.getCaptures();
      res.json(captures);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch captures' });
    }
  });

  // Create capture
  app.post('/api/captures', upload.single('image'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: 'No image file provided' });
      }

      const captureData = {
        filename: req.file.originalname,
        filePath: req.file.path,
        detections: req.body.detections ? JSON.parse(req.body.detections) : [],
        modelConfigId: req.body.modelConfigId ? parseInt(req.body.modelConfigId) : null,
      };

      const capture = await storage.createCapture(captureData);
      res.json(capture);
    } catch (error) {
      res.status(400).json({ error: 'Failed to create capture' });
    }
  });

  // Delete capture
  app.delete('/api/captures/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteCapture(id);
      
      if (!success) {
        return res.status(404).json({ error: 'Capture not found' });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to delete capture' });
    }
  });

  // Get performance metrics
  app.get('/api/metrics', async (req, res) => {
    try {
      const metrics = await storage.getLatestPerformanceMetrics();
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch metrics' });
    }
  });

  // Get performance metrics history
  app.get('/api/metrics/history', async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      const metrics = await storage.getPerformanceMetricsHistory(limit);
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch metrics history' });
    }
  });

  // Export results
  app.get('/api/export/results', async (req, res) => {
    try {
      const captures = await storage.getCaptures();
      const configurations = await storage.getModelConfigurations();
      const metrics = await storage.getPerformanceMetricsHistory(50);
      
      const exportData = {
        captures,
        configurations,
        metrics,
        exportedAt: new Date().toISOString(),
      };
      
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', 'attachment; filename="ai_camera_results.json"');
      res.json(exportData);
    } catch (error) {
      res.status(500).json({ error: 'Failed to export results' });
    }
  });

  return httpServer;
}
