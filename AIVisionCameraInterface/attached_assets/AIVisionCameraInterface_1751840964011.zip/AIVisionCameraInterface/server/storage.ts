import {
  users,
  aiModels,
  modelConfigurations,
  captures,
  performanceMetrics,
  type User,
  type InsertUser,
  type AiModel,
  type InsertAiModel,
  type ModelConfiguration,
  type InsertModelConfiguration,
  type Capture,
  type InsertCapture,
  type PerformanceMetrics,
  type InsertPerformanceMetrics,
  type Detection,
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // AI Model operations
  getAiModels(): Promise<AiModel[]>;
  getAiModel(id: number): Promise<AiModel | undefined>;
  createAiModel(model: InsertAiModel): Promise<AiModel>;
  updateAiModel(id: number, model: Partial<InsertAiModel>): Promise<AiModel | undefined>;

  // Model Configuration operations
  getModelConfigurations(): Promise<ModelConfiguration[]>;
  getModelConfiguration(id: number): Promise<ModelConfiguration | undefined>;
  createModelConfiguration(config: InsertModelConfiguration): Promise<ModelConfiguration>;
  updateModelConfiguration(id: number, config: Partial<InsertModelConfiguration>): Promise<ModelConfiguration | undefined>;

  // Capture operations
  getCaptures(): Promise<Capture[]>;
  getCapture(id: number): Promise<Capture | undefined>;
  createCapture(capture: InsertCapture): Promise<Capture>;
  deleteCapture(id: number): Promise<boolean>;

  // Performance Metrics operations
  getLatestPerformanceMetrics(): Promise<PerformanceMetrics | undefined>;
  createPerformanceMetrics(metrics: InsertPerformanceMetrics): Promise<PerformanceMetrics>;
  getPerformanceMetricsHistory(limit?: number): Promise<PerformanceMetrics[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private aiModels: Map<number, AiModel>;
  private modelConfigurations: Map<number, ModelConfiguration>;
  private captures: Map<number, Capture>;
  private performanceMetrics: Map<number, PerformanceMetrics>;
  private currentUserId: number;
  private currentAiModelId: number;
  private currentModelConfigId: number;
  private currentCaptureId: number;
  private currentMetricsId: number;

  constructor() {
    this.users = new Map();
    this.aiModels = new Map();
    this.modelConfigurations = new Map();
    this.captures = new Map();
    this.performanceMetrics = new Map();
    this.currentUserId = 1;
    this.currentAiModelId = 1;
    this.currentModelConfigId = 1;
    this.currentCaptureId = 1;
    this.currentMetricsId = 1;

    // Initialize with default AI models
    this.initializeDefaultModels();
  }

  private initializeDefaultModels() {
    const defaultModels: Omit<AiModel, "id">[] = [
      {
        name: "YOLOv8 Object Detection",
        type: "object_detection",
        modelPath: "/models/yolov8.onnx",
        isActive: true,
        createdAt: new Date(),
      },
      {
        name: "ResNet Classification",
        type: "classification",
        modelPath: "/models/resnet.onnx",
        isActive: false,
        createdAt: new Date(),
      },
      {
        name: "MobileNet Lightweight",
        type: "classification",
        modelPath: "/models/mobilenet.onnx",
        isActive: false,
        createdAt: new Date(),
      },
    ];

    defaultModels.forEach((model) => {
      const id = this.currentAiModelId++;
      this.aiModels.set(id, { ...model, id });
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAiModels(): Promise<AiModel[]> {
    return Array.from(this.aiModels.values());
  }

  async getAiModel(id: number): Promise<AiModel | undefined> {
    return this.aiModels.get(id);
  }

  async createAiModel(model: InsertAiModel): Promise<AiModel> {
    const id = this.currentAiModelId++;
    const aiModel: AiModel = { ...model, id, createdAt: new Date() };
    this.aiModels.set(id, aiModel);
    return aiModel;
  }

  async updateAiModel(id: number, model: Partial<InsertAiModel>): Promise<AiModel | undefined> {
    const existingModel = this.aiModels.get(id);
    if (!existingModel) return undefined;

    const updatedModel: AiModel = { ...existingModel, ...model };
    this.aiModels.set(id, updatedModel);
    return updatedModel;
  }

  async getModelConfigurations(): Promise<ModelConfiguration[]> {
    return Array.from(this.modelConfigurations.values());
  }

  async getModelConfiguration(id: number): Promise<ModelConfiguration | undefined> {
    return this.modelConfigurations.get(id);
  }

  async createModelConfiguration(config: InsertModelConfiguration): Promise<ModelConfiguration> {
    const id = this.currentModelConfigId++;
    const modelConfig: ModelConfiguration = { ...config, id, createdAt: new Date() };
    this.modelConfigurations.set(id, modelConfig);
    return modelConfig;
  }

  async updateModelConfiguration(id: number, config: Partial<InsertModelConfiguration>): Promise<ModelConfiguration | undefined> {
    const existingConfig = this.modelConfigurations.get(id);
    if (!existingConfig) return undefined;

    const updatedConfig: ModelConfiguration = { ...existingConfig, ...config };
    this.modelConfigurations.set(id, updatedConfig);
    return updatedConfig;
  }

  async getCaptures(): Promise<Capture[]> {
    return Array.from(this.captures.values()).sort((a, b) => 
      new Date(b.capturedAt!).getTime() - new Date(a.capturedAt!).getTime()
    );
  }

  async getCapture(id: number): Promise<Capture | undefined> {
    return this.captures.get(id);
  }

  async createCapture(capture: InsertCapture): Promise<Capture> {
    const id = this.currentCaptureId++;
    const newCapture: Capture = { ...capture, id, capturedAt: new Date() };
    this.captures.set(id, newCapture);
    return newCapture;
  }

  async deleteCapture(id: number): Promise<boolean> {
    return this.captures.delete(id);
  }

  async getLatestPerformanceMetrics(): Promise<PerformanceMetrics | undefined> {
    const metrics = Array.from(this.performanceMetrics.values()).sort((a, b) => 
      new Date(b.timestamp!).getTime() - new Date(a.timestamp!).getTime()
    );
    return metrics[0];
  }

  async createPerformanceMetrics(metrics: InsertPerformanceMetrics): Promise<PerformanceMetrics> {
    const id = this.currentMetricsId++;
    const newMetrics: PerformanceMetrics = { ...metrics, id, timestamp: new Date() };
    this.performanceMetrics.set(id, newMetrics);
    return newMetrics;
  }

  async getPerformanceMetricsHistory(limit = 100): Promise<PerformanceMetrics[]> {
    return Array.from(this.performanceMetrics.values())
      .sort((a, b) => new Date(b.timestamp!).getTime() - new Date(a.timestamp!).getTime())
      .slice(0, limit);
  }
}

export const storage = new MemStorage();
