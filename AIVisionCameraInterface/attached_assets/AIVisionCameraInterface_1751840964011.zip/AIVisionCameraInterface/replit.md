# AI Camera Training System

## Overview

This is a full-stack AI camera training application built with modern web technologies. The system provides real-time AI inference capabilities for computer vision tasks, specifically focused on object detection with configurable models and parameters. The application features a React frontend with real-time camera feed processing and an Express backend with WebSocket support for live AI detection streaming.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Real-time Communication**: WebSocket client for live AI detection streaming
- **Camera Integration**: Native Web APIs for camera access and video streaming

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Real-time Communication**: WebSocket server for live inference streaming
- **File Upload**: Multer for handling image/video uploads
- **Development Server**: Vite for development with HMR support

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Schema Management**: Drizzle Kit for migrations and schema synchronization
- **Connection**: @neondatabase/serverless for optimized serverless connections

### AI/ML Processing
- **Model Support**: Object detection models with configurable parameters
- **Real-time Processing**: WebSocket-based frame processing pipeline
- **Performance Monitoring**: Built-in metrics tracking for FPS, latency, and resource usage
- **Model Configuration**: Dynamic confidence thresholds, IoU settings, and class filtering

## Key Components

### Database Schema
The application uses five main database tables:
- **users**: User authentication and management
- **aiModels**: AI model definitions and metadata
- **modelConfigurations**: Per-user model configuration settings
- **captures**: Stored camera captures with detection results
- **performanceMetrics**: Real-time performance monitoring data

### Frontend Components
- **CameraFeed**: Real-time camera streaming with AI detection overlays
- **ConfigurationPanel**: Dynamic model parameter adjustment interface
- **PerformanceMetrics**: Live system performance monitoring dashboard
- **RecentCaptures**: Gallery of processed images with detection results

### Backend Services
- **Storage Layer**: Abstracted storage interface with in-memory and database implementations
- **WebSocket Handler**: Real-time communication for AI inference streaming
- **API Routes**: RESTful endpoints for model management and data operations
- **File Management**: Upload and storage handling for captured images

## Data Flow

### Real-time AI Processing Flow
1. Camera captures frames in the browser
2. Frames are sent via WebSocket to the backend
3. Backend processes frames with configured AI models
4. Detection results are broadcasted to connected clients
5. Frontend overlays detection boxes on the live camera feed

### Configuration Management Flow
1. Users adjust model parameters through the configuration panel
2. Settings are validated and sent to the backend
3. Backend updates model configurations in the database
4. Changes are broadcasted to all connected clients via WebSocket
5. AI processing pipeline uses updated parameters for subsequent frames

### Performance Monitoring Flow
1. Backend continuously monitors system metrics (FPS, latency, memory usage)
2. Metrics are stored in the database and broadcasted via WebSocket
3. Frontend displays real-time performance charts and statistics
4. Historical metrics are available for analysis and optimization

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL database connection
- **drizzle-orm**: Type-safe database ORM with PostgreSQL support
- **@tanstack/react-query**: Server state management and caching
- **@radix-ui/react-***: Accessible UI component primitives
- **ws**: WebSocket server implementation
- **multer**: File upload handling middleware

### Development Dependencies
- **vite**: Fast build tool and development server
- **tsx**: TypeScript execution environment
- **tailwindcss**: Utility-first CSS framework
- **@types/node**: TypeScript definitions for Node.js

### UI Component Library
The application uses shadcn/ui components built on Radix UI primitives, providing:
- Accessible form controls and inputs
- Modal dialogs and overlays
- Data visualization components
- Consistent design system with theme support

## Deployment Strategy

### Development Environment
- **Frontend**: Vite development server with HMR
- **Backend**: tsx with auto-restart on file changes
- **Database**: Neon Database with connection pooling
- **Real-time Features**: WebSocket server integrated with Express

### Production Build
- **Frontend**: Vite production build with optimized assets
- **Backend**: ESBuild bundling for Node.js deployment
- **Database**: Persistent PostgreSQL with migration support
- **Static Assets**: Served through Express static middleware

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string (required)
- **NODE_ENV**: Environment flag for development/production modes
- **REPL_ID**: Replit-specific environment detection

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- July 07, 2025. Initial setup