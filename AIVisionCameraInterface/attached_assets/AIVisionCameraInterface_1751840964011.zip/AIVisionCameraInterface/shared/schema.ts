import { pgTable, text, serial, integer, boolean, timestamp, jsonb, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const aiModels = pgTable("ai_models", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'object_detection', 'classification', etc.
  modelPath: text("model_path").notNull(),
  isActive: boolean("is_active").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const modelConfigurations = pgTable("model_configurations", {
  id: serial("id").primaryKey(),
  modelId: integer("model_id").references(() => aiModels.id),
  confidence: real("confidence").default(0.75),
  iouThreshold: real("iou_threshold").default(0.45),
  maxDetections: integer("max_detections").default(10),
  enabledClasses: jsonb("enabled_classes").$type<string[]>().default([]),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const captures = pgTable("captures", {
  id: serial("id").primaryKey(),
  filename: text("filename").notNull(),
  filePath: text("file_path").notNull(),
  detections: jsonb("detections").$type<Detection[]>().default([]),
  modelConfigId: integer("model_config_id").references(() => modelConfigurations.id),
  capturedAt: timestamp("captured_at").defaultNow(),
});

export const performanceMetrics = pgTable("performance_metrics", {
  id: serial("id").primaryKey(),
  fps: real("fps").default(0),
  latency: real("latency").default(0), // in milliseconds
  memoryUsage: real("memory_usage").default(0), // in MB
  gpuUsage: real("gpu_usage").default(0), // percentage
  processingTime: real("processing_time").default(0), // in milliseconds
  timestamp: timestamp("timestamp").defaultNow(),
});

// Zod schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertAiModelSchema = createInsertSchema(aiModels).pick({
  name: true,
  type: true,
  modelPath: true,
  isActive: true,
});

export const insertModelConfigSchema = createInsertSchema(modelConfigurations).pick({
  modelId: true,
  confidence: true,
  iouThreshold: true,
  maxDetections: true,
  enabledClasses: true,
  userId: true,
});

export const insertCaptureSchema = createInsertSchema(captures).pick({
  filename: true,
  filePath: true,
  detections: true,
  modelConfigId: true,
});

export const insertPerformanceMetricsSchema = createInsertSchema(performanceMetrics).pick({
  fps: true,
  latency: true,
  memoryUsage: true,
  gpuUsage: true,
  processingTime: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type AiModel = typeof aiModels.$inferSelect;
export type InsertAiModel = z.infer<typeof insertAiModelSchema>;

export type ModelConfiguration = typeof modelConfigurations.$inferSelect;
export type InsertModelConfiguration = z.infer<typeof insertModelConfigSchema>;

export type Capture = typeof captures.$inferSelect;
export type InsertCapture = z.infer<typeof insertCaptureSchema>;

export type PerformanceMetrics = typeof performanceMetrics.$inferSelect;
export type InsertPerformanceMetrics = z.infer<typeof insertPerformanceMetricsSchema>;

// Additional types for AI functionality
export interface Detection {
  id: string;
  label: string;
  confidence: number;
  bbox: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  color: string;
}

export interface CameraSettings {
  resolution: string;
  fps: number;
  deviceId?: string;
}

export interface ModelStatus {
  isActive: boolean;
  isLoading: boolean;
  error?: string;
  modelType: string;
}

export interface AIModelConfig {
  confidence: number;
  iouThreshold: number;
  maxDetections: number;
  enabledClasses: string[];
  modelType: string;
  apiEndpoint?: string;
  apiKey?: string;
}

export interface ModelTypeOption {
  id: string;
  name: string;
  description: string;
  endpoint: string;
  requiresApiKey: boolean;
}
