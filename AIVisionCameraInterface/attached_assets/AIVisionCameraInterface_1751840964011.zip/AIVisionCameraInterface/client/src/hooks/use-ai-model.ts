import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useWebSocket } from "./use-websocket";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { AiModel, ModelConfiguration, AIModelConfig, Detection } from "@shared/schema";

interface UseAiModelReturn {
  models: AiModel[];
  configurations: ModelConfiguration[];
  currentConfig: AIModelConfig;
  isLoading: boolean;
  updateConfiguration: (config: Partial<AIModelConfig>) => void;
  applyConfiguration: () => void;
  detections: Detection[];
  modelStatus: {
    isActive: boolean;
    isLoading: boolean;
    error?: string;
  };
}

export function useAiModel(): UseAiModelReturn {
  const [currentConfig, setCurrentConfig] = useState<AIModelConfig>({
    confidence: 0.75,
    iouThreshold: 0.45,
    maxDetections: 10,
    enabledClasses: ['person', 'vehicle'],
    modelType: 'object_detection',
  });
  
  const [detections, setDetections] = useState<Detection[]>([]);
  const [modelStatus, setModelStatus] = useState({
    isActive: true,
    isLoading: false,
    error: undefined,
  });

  const { sendMessage, lastMessage } = useWebSocket();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch AI models
  const { data: models = [], isLoading: modelsLoading } = useQuery({
    queryKey: ['/api/models'],
  });

  // Fetch configurations
  const { data: configurations = [], isLoading: configsLoading } = useQuery({
    queryKey: ['/api/configurations'],
  });

  // Update configuration mutation
  const updateConfigMutation = useMutation({
    mutationFn: async (config: Partial<AIModelConfig>) => {
      const response = await apiRequest('POST', '/api/configurations', {
        ...currentConfig,
        ...config,
      });
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/configurations'] });
      toast({
        title: "Configuration Updated",
        description: "AI model parameters have been applied successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Configuration Error",
        description: "Failed to update AI model configuration.",
        variant: "destructive",
      });
    },
  });

  // Handle WebSocket messages
  useEffect(() => {
    if (!lastMessage) return;

    switch (lastMessage.type) {
      case 'ai_detection':
        setDetections(lastMessage.detections || []);
        break;
      case 'config_updated':
        if (lastMessage.config) {
          setCurrentConfig(prev => ({
            ...prev,
            ...lastMessage.config,
          }));
        }
        break;
      case 'model_status':
        setModelStatus(lastMessage.status);
        break;
    }
  }, [lastMessage]);

  const updateConfiguration = (config: Partial<AIModelConfig>) => {
    setCurrentConfig(prev => ({ ...prev, ...config }));
  };

  const applyConfiguration = () => {
    setModelStatus(prev => ({ ...prev, isLoading: true }));
    
    // Send configuration update via WebSocket
    sendMessage({
      type: 'update_config',
      config: currentConfig,
    });
    
    // Also update via API
    updateConfigMutation.mutate(currentConfig);
  };

  // Simulate model status updates
  useEffect(() => {
    const interval = setInterval(() => {
      setModelStatus(prev => ({
        ...prev,
        isLoading: false,
        isActive: true,
      }));
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return {
    models,
    configurations,
    currentConfig,
    isLoading: modelsLoading || configsLoading || updateConfigMutation.isPending,
    updateConfiguration,
    applyConfiguration,
    detections,
    modelStatus,
  };
}
