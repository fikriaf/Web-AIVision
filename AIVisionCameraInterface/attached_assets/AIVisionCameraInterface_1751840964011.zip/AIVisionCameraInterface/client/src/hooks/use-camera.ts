import { useEffect, useRef, useState } from "react";
import { useToast } from "@/hooks/use-toast";

interface CameraSettings {
  resolution: string;
  fps: number;
  deviceId?: string;
}

interface UseCameraReturn {
  videoRef: React.RefObject<HTMLVideoElement>;
  isActive: boolean;
  error: string | null;
  startCamera: () => Promise<void>;
  stopCamera: () => void;
  takeSnapshot: () => string | null;
  devices: MediaDeviceInfo[];
  settings: CameraSettings;
  updateSettings: (newSettings: Partial<CameraSettings>) => void;
}

const parseResolution = (resolution: string): { width: number; height: number } => {
  const [width, height] = resolution.split('x').map(Number);
  return { width, height };
};

export function useCamera(): UseCameraReturn {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [isActive, setIsActive] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [settings, setSettings] = useState<CameraSettings>({
    resolution: "1920x1080",
    fps: 30,
  });
  const { toast } = useToast();

  useEffect(() => {
    // Get available camera devices
    const getDevices = async () => {
      try {
        const deviceList = await navigator.mediaDevices.enumerateDevices();
        const videoDevices = deviceList.filter(device => device.kind === 'videoinput');
        setDevices(videoDevices);
      } catch (err) {
        console.error('Error getting devices:', err);
      }
    };

    getDevices();

    // Listen for device changes
    navigator.mediaDevices.addEventListener('devicechange', getDevices);
    
    return () => {
      navigator.mediaDevices.removeEventListener('devicechange', getDevices);
    };
  }, []);

  const startCamera = async () => {
    try {
      setError(null);
      
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }

      const { width, height } = parseResolution(settings.resolution);
      
      const constraints: MediaStreamConstraints = {
        video: {
          deviceId: settings.deviceId ? { exact: settings.deviceId } : undefined,
          width: { ideal: width },
          height: { ideal: height },
          frameRate: { ideal: settings.fps },
        },
        audio: false,
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }

      setIsActive(true);
      toast({
        title: "Camera Started",
        description: "Camera is now active and ready for AI processing.",
      });
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Unknown camera error";
      setError(errorMessage);
      setIsActive(false);
      toast({
        title: "Camera Error",
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }

    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }

    setIsActive(false);
    setError(null);
    toast({
      title: "Camera Stopped",
      description: "Camera has been deactivated.",
    });
  };

  const takeSnapshot = (): string | null => {
    if (!videoRef.current || !isActive) return null;

    const canvas = document.createElement('canvas');
    const video = videoRef.current;
    
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    
    ctx.drawImage(video, 0, 0);
    return canvas.toDataURL('image/png');
  };

  const updateSettings = (newSettings: Partial<CameraSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  useEffect(() => {
    // Restart camera if settings change and camera is active
    if (isActive) {
      startCamera();
    }
  }, [settings.resolution, settings.fps, settings.deviceId]);

  useEffect(() => {
    // Cleanup on unmount
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  return {
    videoRef,
    isActive,
    error,
    startCamera,
    stopCamera,
    takeSnapshot,
    devices,
    settings,
    updateSettings,
  };
}
