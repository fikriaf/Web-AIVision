import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Eye, Image, Trash2 } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Capture } from "@shared/schema";

interface RecentCapturesProps {
  className?: string;
}

export function RecentCaptures({ className }: RecentCapturesProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: captures = [], isLoading } = useQuery({
    queryKey: ['/api/captures'],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/captures/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/captures'] });
      toast({
        title: "Capture Deleted",
        description: "Capture has been removed successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Delete Error",
        description: "Failed to delete capture.",
        variant: "destructive",
      });
    },
  });

  const handleDelete = (id: number) => {
    deleteMutation.mutate(id);
  };

  const formatDate = (dateString: string | Date) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  };

  if (isLoading) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle>Recent Captures</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="aspect-video bg-muted rounded-lg"></div>
                <div className="mt-2 space-y-1">
                  <div className="h-4 bg-muted rounded w-3/4"></div>
                  <div className="h-3 bg-muted rounded w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle>Recent Captures</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {captures.slice(0, 8).map((capture: Capture) => (
            <div key={capture.id} className="relative group cursor-pointer">
              <div className="aspect-video bg-muted rounded-lg overflow-hidden flex items-center justify-center">
                <Image className="h-8 w-8 text-muted-foreground" />
              </div>
              
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center space-x-2">
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => {
                    // In a real app, this would open a modal or navigate to detailed view
                    toast({
                      title: "View Capture",
                      description: `Viewing ${capture.filename}`,
                    });
                  }}
                >
                  <Eye className="h-4 w-4" />
                </Button>
                <Button
                  size="sm"
                  variant="destructive"
                  onClick={() => handleDelete(capture.id)}
                  disabled={deleteMutation.isPending}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
              
              <div className="mt-2">
                <p className="text-sm text-muted-foreground truncate">
                  {capture.capturedAt && formatDate(capture.capturedAt)}
                </p>
                <p className="text-xs text-muted-foreground">
                  {capture.detections?.length || 0} detections
                </p>
              </div>
            </div>
          ))}
          
          {captures.length === 0 && (
            <div className="col-span-full text-center py-8">
              <Image className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">No captures yet</p>
              <p className="text-sm text-muted-foreground">
                Use the camera to capture images with AI detections
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
