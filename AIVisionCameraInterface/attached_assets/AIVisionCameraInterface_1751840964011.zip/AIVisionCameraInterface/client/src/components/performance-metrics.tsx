import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useQuery } from "@tanstack/react-query";
import { useWebSocket } from "@/hooks/use-websocket";
import type { PerformanceMetrics } from "@shared/schema";

interface PerformanceMetricsProps {
  className?: string;
}

export function PerformanceMetrics({ className }: PerformanceMetricsProps) {
  const [metrics, setMetrics] = useState<PerformanceMetrics | null>(null);
  const [totalDetections, setTotalDetections] = useState(1247);
  const [accuracy, setAccuracy] = useState(94.3);
  
  const { lastMessage } = useWebSocket();

  // Fetch initial metrics
  const { data: initialMetrics } = useQuery({
    queryKey: ['/api/metrics'],
    refetchInterval: 5000,
  });

  useEffect(() => {
    if (initialMetrics) {
      setMetrics(initialMetrics);
    }
  }, [initialMetrics]);

  // Handle real-time metrics updates
  useEffect(() => {
    if (lastMessage?.type === 'performance_metrics') {
      setMetrics(lastMessage.metrics);
    }
  }, [lastMessage]);

  // Simulate detection stats updates
  useEffect(() => {
    const interval = setInterval(() => {
      setTotalDetections(prev => prev + Math.floor(Math.random() * 3));
      setAccuracy(prev => Math.min(99.9, prev + (Math.random() - 0.5) * 0.1));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const formatMemory = (mb: number) => {
    if (mb >= 1024) {
      return `${(mb / 1024).toFixed(1)}GB`;
    }
    return `${mb.toFixed(0)}MB`;
  };

  const getProgressColor = (percentage: number) => {
    if (percentage >= 80) return "bg-error";
    if (percentage >= 60) return "bg-warning";
    return "bg-success";
  };

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle>Performance</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Processing Time */}
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Processing Time</span>
          <span className="text-sm font-mono">
            {metrics?.processingTime?.toFixed(0) || '45'}ms
          </span>
        </div>
        <Progress 
          value={Math.min(100, (metrics?.processingTime || 45) / 100 * 100)} 
          className="w-full"
        />

        {/* Memory Usage */}
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Memory Usage</span>
          <span className="text-sm font-mono">
            {formatMemory(metrics?.memoryUsage || 2100)}
          </span>
        </div>
        <Progress 
          value={Math.min(100, (metrics?.memoryUsage || 2100) / 4000 * 100)} 
          className="w-full"
        />

        {/* GPU Usage */}
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">GPU Usage</span>
          <span className="text-sm font-mono">
            {metrics?.gpuUsage?.toFixed(0) || '85'}%
          </span>
        </div>
        <Progress 
          value={metrics?.gpuUsage || 85} 
          className="w-full"
        />

        {/* FPS */}
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">FPS</span>
          <span className="text-sm font-mono">
            {metrics?.fps?.toFixed(0) || '30'}
          </span>
        </div>
        <Progress 
          value={Math.min(100, (metrics?.fps || 30) / 60 * 100)} 
          className="w-full"
        />

        {/* Latency */}
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Latency</span>
          <span className="text-sm font-mono">
            {metrics?.latency?.toFixed(0) || '45'}ms
          </span>
        </div>
        <Progress 
          value={Math.min(100, 100 - (metrics?.latency || 45) / 100 * 100)} 
          className="w-full"
        />

        {/* Detection Stats */}
        <div className="mt-6 pt-4 border-t">
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold">
                {totalDetections.toLocaleString()}
              </div>
              <div className="text-xs text-muted-foreground">
                Total Detections
              </div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">
                {accuracy.toFixed(1)}%
              </div>
              <div className="text-xs text-muted-foreground">
                Accuracy
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
