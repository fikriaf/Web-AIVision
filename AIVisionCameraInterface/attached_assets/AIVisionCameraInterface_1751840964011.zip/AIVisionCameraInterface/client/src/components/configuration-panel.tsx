import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Check, Download, Save, FileText } from "lucide-react";
import { useAiModel } from "@/hooks/use-ai-model";
import { useToast } from "@/hooks/use-toast";

interface ConfigurationPanelProps {
  className?: string;
}

export function ConfigurationPanel({ className }: ConfigurationPanelProps) {
  const { 
    models, 
    currentConfig, 
    updateConfiguration, 
    applyConfiguration, 
    isLoading,
    modelStatus 
  } = useAiModel();
  const { toast } = useToast();

  const availableClasses = [
    'person', 'vehicle', 'animal', 'bicycle', 'motorcycle', 
    'bus', 'truck', 'dog', 'cat', 'bird'
  ];

  const handleConfidenceChange = (value: number[]) => {
    updateConfiguration({ confidence: value[0] });
  };

  const handleIouChange = (value: number[]) => {
    updateConfiguration({ iouThreshold: value[0] });
  };

  const handleMaxDetectionsChange = (value: string) => {
    updateConfiguration({ maxDetections: parseInt(value) });
  };

  const handleClassToggle = (className: string, checked: boolean) => {
    const newEnabledClasses = checked
      ? [...currentConfig.enabledClasses, className]
      : currentConfig.enabledClasses.filter(c => c !== className);
    
    updateConfiguration({ enabledClasses: newEnabledClasses });
  };

  const handleExportResults = async () => {
    try {
      const response = await fetch('/api/export/results');
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'ai_camera_results.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        
        toast({
          title: "Export Complete",
          description: "Results exported successfully.",
        });
      }
    } catch (error) {
      toast({
        title: "Export Error",
        description: "Failed to export results.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className={`space-y-6 ${className}`}>
      {/* AI Model Configuration */}
      <Card>
        <CardHeader>
          <CardTitle>AI Model Config</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Model Selection */}
          <div>
            <Label className="text-sm font-medium mb-2">Model Type</Label>
            <Select value={currentConfig.modelType} onValueChange={(value) => updateConfiguration({ modelType: value })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="object_detection">YOLOv8 (Object Detection)</SelectItem>
                <SelectItem value="classification">ResNet (Classification)</SelectItem>
                <SelectItem value="lightweight">MobileNet (Lightweight)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Confidence Threshold */}
          <div>
            <Label className="text-sm font-medium mb-2">
              Confidence Threshold
              <span className="text-primary font-mono text-xs ml-2">
                {currentConfig.confidence.toFixed(2)}
              </span>
            </Label>
            <Slider
              value={[currentConfig.confidence]}
              onValueChange={handleConfidenceChange}
              min={0.1}
              max={1.0}
              step={0.05}
              className="mt-2"
            />
            <div className="flex justify-between text-xs text-muted-foreground mt-1">
              <span>0.1</span>
              <span>1.0</span>
            </div>
          </div>

          {/* IoU Threshold */}
          <div>
            <Label className="text-sm font-medium mb-2">
              IoU Threshold
              <span className="text-primary font-mono text-xs ml-2">
                {currentConfig.iouThreshold.toFixed(2)}
              </span>
            </Label>
            <Slider
              value={[currentConfig.iouThreshold]}
              onValueChange={handleIouChange}
              min={0.1}
              max={0.9}
              step={0.05}
              className="mt-2"
            />
            <div className="flex justify-between text-xs text-muted-foreground mt-1">
              <span>0.1</span>
              <span>0.9</span>
            </div>
          </div>

          {/* Max Detections */}
          <div>
            <Label className="text-sm font-medium mb-2">Max Detections</Label>
            <Input
              type="number"
              value={currentConfig.maxDetections}
              onChange={(e) => handleMaxDetectionsChange(e.target.value)}
              min="1"
              max="100"
            />
          </div>

          {/* Class Filtering */}
          <div>
            <Label className="text-sm font-medium mb-2">Detect Classes</Label>
            <div className="space-y-2 max-h-32 overflow-y-auto">
              {availableClasses.map((className) => (
                <div key={className} className="flex items-center space-x-2">
                  <Checkbox
                    id={className}
                    checked={currentConfig.enabledClasses.includes(className)}
                    onCheckedChange={(checked) => handleClassToggle(className, checked as boolean)}
                  />
                  <Label htmlFor={className} className="text-sm">
                    {className}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          {/* Apply Configuration */}
          <Button
            onClick={applyConfiguration}
            disabled={isLoading}
            className="w-full"
          >
            <Check className="h-4 w-4 mr-2" />
            {isLoading ? "Applying..." : "Apply Configuration"}
          </Button>
        </CardContent>
      </Card>

      {/* Export Options */}
      <Card>
        <CardHeader>
          <CardTitle>Export & Save</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Button
            onClick={handleExportResults}
            className="w-full bg-success hover:bg-success/90"
          >
            <Download className="h-4 w-4 mr-2" />
            Export Results (JSON)
          </Button>
          
          <Button
            variant="outline"
            className="w-full"
            onClick={() => {
              const configJson = JSON.stringify(currentConfig, null, 2);
              const blob = new Blob([configJson], { type: 'application/json' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'ai_model_config.json';
              document.body.appendChild(a);
              a.click();
              document.body.removeChild(a);
              URL.revokeObjectURL(url);
            }}
          >
            <Save className="h-4 w-4 mr-2" />
            Save Configuration
          </Button>
          
          <Button
            variant="outline"
            className="w-full"
            onClick={() => toast({
              title: "Feature Coming Soon",
              description: "Report generation will be available in the next update.",
            })}
          >
            <FileText className="h-4 w-4 mr-2" />
            Generate Report
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
