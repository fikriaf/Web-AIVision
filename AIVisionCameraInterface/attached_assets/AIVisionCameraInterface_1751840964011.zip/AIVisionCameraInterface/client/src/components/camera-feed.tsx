import { useEffect, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Camera, Video, Maximize, Square } from "lucide-react";
import { useCamera } from "@/hooks/use-camera";
import { useAiModel } from "@/hooks/use-ai-model";
import { useToast } from "@/hooks/use-toast";
import type { Detection } from "@shared/schema";

interface CameraFeedProps {
  className?: string;
}

export function CameraFeed({ className }: CameraFeedProps) {
  const {
    videoRef,
    isActive,
    error,
    startCamera,
    stopCamera,
    takeSnapshot,
    devices,
    settings,
    updateSettings,
  } = useCamera();
  
  const { detections, currentConfig } = useAiModel();
  const { toast } = useToast();
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Draw detection overlays
  useEffect(() => {
    if (!canvasRef.current || !videoRef.current || !isActive) return;

    const canvas = canvasRef.current;
    const video = videoRef.current;
    const ctx = canvas.getContext('2d');
    
    if (!ctx) return;

    // Set canvas size to match video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw detection boxes
    detections.forEach((detection: Detection) => {
      const { bbox, label, confidence, color } = detection;
      
      const x = bbox.x * canvas.width;
      const y = bbox.y * canvas.height;
      const width = bbox.width * canvas.width;
      const height = bbox.height * canvas.height;

      // Draw bounding box
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y, width, height);

      // Draw label background
      ctx.fillStyle = color;
      ctx.fillRect(x, y - 30, width, 30);

      // Draw label text
      ctx.fillStyle = 'white';
      ctx.font = '14px Arial';
      ctx.fillText(
        `${label} ${(confidence * 100).toFixed(1)}%`,
        x + 5,
        y - 10
      );
    });
  }, [detections, isActive]);

  const handleTakeSnapshot = async () => {
    const dataUrl = takeSnapshot();
    if (dataUrl) {
      try {
        // Convert data URL to blob
        const response = await fetch(dataUrl);
        const blob = await response.blob();
        const file = new File([blob], `snapshot_${Date.now()}.png`, { type: 'image/png' });
        
        // Create form data
        const formData = new FormData();
        formData.append('image', file);
        formData.append('detections', JSON.stringify(detections));
        
        // Save capture
        const saveResponse = await fetch('/api/captures', {
          method: 'POST',
          body: formData,
        });
        
        if (saveResponse.ok) {
          toast({
            title: "Snapshot Captured",
            description: "Image saved with AI detection data.",
          });
        }
      } catch (error) {
        toast({
          title: "Capture Error",
          description: "Failed to save snapshot.",
          variant: "destructive",
        });
      }
    }
  };

  return (
    <Card className={className}>
      {/* Header */}
      <div className="bg-muted/50 px-6 py-4 border-b">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h2 className="text-lg font-semibold">Camera Feed</h2>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
              <span className="text-sm text-muted-foreground">Live</span>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              size="sm"
              onClick={handleTakeSnapshot}
              disabled={!isActive}
              className="bg-success hover:bg-success/90"
            >
              <Camera className="h-4 w-4 mr-1" />
              Capture
            </Button>
            <Button
              size="sm"
              variant="outline"
            >
              <Maximize className="h-4 w-4 mr-1" />
              Fullscreen
            </Button>
          </div>
        </div>
      </div>

      {/* Video Feed */}
      <CardContent className="p-0">
        <div className="relative bg-black aspect-video">
          <video
            ref={videoRef}
            className="w-full h-full object-cover"
            autoPlay
            muted
            playsInline
          />
          
          {/* Detection overlay canvas */}
          <canvas
            ref={canvasRef}
            className="absolute inset-0 w-full h-full pointer-events-none"
          />

          {/* Error/inactive state */}
          {(!isActive || error) && (
            <div className="absolute inset-0 flex items-center justify-center bg-gray-900/80">
              <div className="text-center">
                <Camera className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <p className="text-gray-400 text-lg mb-2">
                  {error ? "Camera Error" : "Camera Preview"}
                </p>
                <p className="text-gray-500 text-sm mb-4">
                  {error || "Live video stream with AI inference overlay"}
                </p>
                {!isActive && (
                  <Button onClick={startCamera} className="bg-primary hover:bg-primary/90">
                    Start Camera
                  </Button>
                )}
              </div>
            </div>
          )}

          {/* Performance metrics overlay */}
          <div className="absolute top-4 right-4 bg-black/50 backdrop-blur-sm rounded-lg p-3 text-white">
            <div className="space-y-1 text-sm">
              <div className="flex justify-between">
                <span>Objects:</span>
                <span className="font-mono">{detections.length}</span>
              </div>
            </div>
          </div>

          {/* Center crosshair */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-8 h-8 border-2 border-white/50 rounded-full flex items-center justify-center">
              <div className="w-1 h-1 bg-white/50 rounded-full"></div>
            </div>
          </div>
        </div>
      </CardContent>

      {/* Controls Footer */}
      <div className="bg-muted/50 px-6 py-4 border-t">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2">
              <label className="text-sm font-medium">Resolution:</label>
              <Select
                value={settings.resolution}
                onValueChange={(value) => updateSettings({ resolution: value })}
              >
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1920x1080">1920x1080</SelectItem>
                  <SelectItem value="1280x720">1280x720</SelectItem>
                  <SelectItem value="640x480">640x480</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center space-x-2">
              <label className="text-sm font-medium">FPS:</label>
              <Select
                value={settings.fps.toString()}
                onValueChange={(value) => updateSettings({ fps: parseInt(value) })}
              >
                <SelectTrigger className="w-20">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="30">30</SelectItem>
                  <SelectItem value="60">60</SelectItem>
                  <SelectItem value="120">120</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <span className="text-sm text-muted-foreground">Status:</span>
            <span className={`text-sm font-medium ${isActive ? 'text-success' : 'text-muted-foreground'}`}>
              {isActive ? 'Active' : 'Inactive'}
            </span>
            {isActive && (
              <Button
                size="sm"
                variant="outline"
                onClick={stopCamera}
              >
                <Square className="h-4 w-4 mr-1" />
                Stop
              </Button>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
}
