import { useEffect, useRef } from "react";
import { useCamera } from "@/hooks/use-camera";
import { useAiModel } from "@/hooks/use-ai-model";
import type { Detection } from "@shared/schema";

interface CameraFeedProps {
  className?: string;
}

export function CameraFeed({ className }: CameraFeedProps) {
  const {
    videoRef,
    isActive,
    error,
    startCamera,
    stopCamera,
    takeSnapshot,
    devices,
    settings,
    updateSettings,
  } = useCamera();
  
  const { detections, currentConfig } = useAiModel();
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Draw detection overlays
  useEffect(() => {
    if (!canvasRef.current || !videoRef.current || !isActive) return;

    const canvas = canvasRef.current;
    const video = videoRef.current;
    const ctx = canvas.getContext('2d');
    
    if (!ctx) return;

    // Set canvas size to match video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw detection boxes
    detections.forEach((detection: Detection) => {
      const { bbox, label, confidence, color } = detection;
      
      const x = bbox.x * canvas.width;
      const y = bbox.y * canvas.height;
      const width = bbox.width * canvas.width;
      const height = bbox.height * canvas.height;

      // Draw bounding box
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y, width, height);

      // Draw label background
      ctx.fillStyle = color;
      ctx.fillRect(x, y - 30, width, 30);

      // Draw label text
      ctx.fillStyle = 'white';
      ctx.font = '14px Arial';
      ctx.fillText(
        `${label} ${(confidence * 100).toFixed(1)}%`,
        x + 5,
        y - 10
      );
    });
  }, [detections, isActive]);

  const handleTakeSnapshot = async () => {
    const dataUrl = takeSnapshot();
    if (dataUrl) {
      try {
        // Convert data URL to blob
        const response = await fetch(dataUrl);
        const blob = await response.blob();
        const file = new File([blob], `snapshot_${Date.now()}.png`, { type: 'image/png' });
        
        // Create form data
        const formData = new FormData();
        formData.append('image', file);
        formData.append('detections', JSON.stringify(detections));
        
        // Save capture
        const saveResponse = await fetch('/api/captures', {
          method: 'POST',
          body: formData,
        });
        
        if (saveResponse.ok) {
          // Show success notification using Bootstrap alert
          const alertDiv = document.createElement('div');
          alertDiv.className = 'alert alert-success alert-dismissible fade show position-fixed top-0 end-0 m-3';
          alertDiv.style.zIndex = '9999';
          alertDiv.innerHTML = `
            <i class="bi bi-check-circle me-2"></i>
            Snapshot captured successfully!
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
          `;
          document.body.appendChild(alertDiv);
          setTimeout(() => alertDiv.remove(), 3000);
        }
      } catch (error) {
        console.error('Capture error:', error);
      }
    }
  };

  return (
    <div className={`card ${className}`}>
      {/* Header */}
      <div className="card-header bg-light d-flex justify-content-between align-items-center">
        <div className="d-flex align-items-center">
          <h5 className="card-title mb-0 me-3">Camera Feed</h5>
          <div className="d-flex align-items-center">
            <span className="status-indicator active me-2"></span>
            <small className="text-muted">Live</small>
          </div>
        </div>
        <div className="d-flex gap-2">
          <button
            className="btn btn-success btn-sm"
            onClick={handleTakeSnapshot}
            disabled={!isActive}
          >
            <i className="bi bi-camera me-1"></i>
            Capture
          </button>
          <button className="btn btn-outline-secondary btn-sm">
            <i className="bi bi-arrows-fullscreen me-1"></i>
            Fullscreen
          </button>
        </div>
      </div>

      {/* Video Feed */}
      <div className="card-body p-0">
        <div className="camera-feed position-relative" style={{ aspectRatio: '16/9' }}>
          <video
            ref={videoRef}
            className="w-100 h-100"
            autoPlay
            muted
            playsInline
            style={{ objectFit: 'cover' }}
          />
          
          {/* Detection overlay canvas */}
          <canvas
            ref={canvasRef}
            className="camera-overlay"
          />

          {/* Error/inactive state */}
          {(!isActive || error) && (
            <div className="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center bg-dark bg-opacity-75">
              <div className="text-center text-white">
                <i className="bi bi-camera display-1 mb-3 text-secondary"></i>
                <h4 className="mb-2">{error ? "Camera Error" : "Camera Preview"}</h4>
                <p className="text-light mb-3">
                  {error || "Live video stream with AI inference overlay"}
                </p>
                {!isActive && (
                  <button onClick={startCamera} className="btn btn-primary">
                    Start Camera
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Performance metrics overlay */}
          <div className="position-absolute top-0 end-0 m-3 bg-dark bg-opacity-75 rounded p-2 text-white">
            <div className="small">
              <div className="d-flex justify-content-between">
                <span>Objects:</span>
                <span className="fw-bold">{detections.length}</span>
              </div>
            </div>
          </div>

          {/* Center crosshair */}
          <div className="position-absolute top-50 start-50 translate-middle">
            <div className="border border-white border-opacity-50 rounded-circle d-flex align-items-center justify-content-center" style={{ width: '32px', height: '32px' }}>
              <div className="bg-white bg-opacity-50 rounded-circle" style={{ width: '4px', height: '4px' }}></div>
            </div>
          </div>
        </div>
      </div>

      {/* Controls Footer */}
      <div className="card-footer bg-light">
        <div className="row align-items-center">
          <div className="col-md-8">
            <div className="row g-3">
              <div className="col-auto d-flex align-items-center">
                <label className="form-label me-2 mb-0 small fw-medium">Resolution:</label>
                <select
                  className="form-select form-select-sm"
                  value={settings.resolution}
                  onChange={(e) => updateSettings({ resolution: e.target.value })}
                  style={{ width: '120px' }}
                >
                  <option value="1920x1080">1920x1080</option>
                  <option value="1280x720">1280x720</option>
                  <option value="640x480">640x480</option>
                </select>
              </div>
              
              <div className="col-auto d-flex align-items-center">
                <label className="form-label me-2 mb-0 small fw-medium">FPS:</label>
                <select
                  className="form-select form-select-sm"
                  value={settings.fps.toString()}
                  onChange={(e) => updateSettings({ fps: parseInt(e.target.value) })}
                  style={{ width: '80px' }}
                >
                  <option value="30">30</option>
                  <option value="60">60</option>
                  <option value="120">120</option>
                </select>
              </div>
            </div>
          </div>
          
          <div className="col-md-4 text-end">
            <div className="d-flex align-items-center justify-content-end">
              <small className="text-muted me-2">Status:</small>
              <span className={`small fw-medium ${isActive ? 'text-success' : 'text-muted'}`}>
                {isActive ? 'Active' : 'Inactive'}
              </span>
              {isActive && (
                <button
                  className="btn btn-outline-danger btn-sm ms-2"
                  onClick={stopCamera}
                >
                  <i className="bi bi-stop me-1"></i>
                  Stop
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}