import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { Capture } from "@shared/schema";

interface RecentCapturesProps {
  className?: string;
}

export function RecentCaptures({ className }: RecentCapturesProps) {
  const queryClient = useQueryClient();

  const { data: captures = [], isLoading } = useQuery({
    queryKey: ['/api/captures'],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/captures/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/captures'] });
      // Show success notification
      const alertDiv = document.createElement('div');
      alertDiv.className = 'alert alert-success alert-dismissible fade show position-fixed top-0 end-0 m-3';
      alertDiv.style.zIndex = '9999';
      alertDiv.innerHTML = `
        <i class="bi bi-trash me-2"></i>
        Capture deleted successfully!
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      `;
      document.body.appendChild(alertDiv);
      setTimeout(() => alertDiv.remove(), 3000);
    },
    onError: () => {
      // Show error notification
      const alertDiv = document.createElement('div');
      alertDiv.className = 'alert alert-danger alert-dismissible fade show position-fixed top-0 end-0 m-3';
      alertDiv.style.zIndex = '9999';
      alertDiv.innerHTML = `
        <i class="bi bi-exclamation-triangle me-2"></i>
        Failed to delete capture!
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      `;
      document.body.appendChild(alertDiv);
      setTimeout(() => alertDiv.remove(), 3000);
    },
  });

  const handleDelete = (id: number) => {
    deleteMutation.mutate(id);
  };

  const handleView = (capture: Capture) => {
    // Show view notification
    const alertDiv = document.createElement('div');
    alertDiv.className = 'alert alert-info alert-dismissible fade show position-fixed top-0 end-0 m-3';
    alertDiv.style.zIndex = '9999';
    alertDiv.innerHTML = `
      <i class="bi bi-eye me-2"></i>
      Viewing ${capture.filename}
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(alertDiv);
    setTimeout(() => alertDiv.remove(), 3000);
  };

  const formatDate = (dateString: string | Date) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  };

  if (isLoading) {
    return (
      <div className={`card ${className}`}>
        <div className="card-header">
          <h5 className="card-title mb-0">Recent Captures</h5>
        </div>
        <div className="card-body">
          <div className="row g-3">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="col-6 col-md-3">
                <div className="capture-thumbnail">
                  <div className="d-flex align-items-center justify-content-center h-100 bg-light">
                    <div className="spinner-border text-primary" role="status">
                      <span className="visually-hidden">Loading...</span>
                    </div>
                  </div>
                </div>
                <div className="mt-2">
                  <div className="placeholder-glow">
                    <span className="placeholder col-8"></span>
                  </div>
                  <div className="placeholder-glow">
                    <span className="placeholder col-6"></span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`card ${className}`}>
      <div className="card-header">
        <h5 className="card-title mb-0">Recent Captures</h5>
      </div>
      <div className="card-body">
        <div className="row g-3">
          {captures.slice(0, 8).map((capture: Capture) => (
            <div key={capture.id} className="col-6 col-md-3">
              <div className="capture-thumbnail position-relative">
                <div className="d-flex align-items-center justify-content-center h-100 bg-light">
                  <i className="bi bi-image display-6 text-muted"></i>
                </div>
                
                <div className="overlay">
                  <div className="d-flex gap-2">
                    <button
                      className="btn btn-sm btn-light"
                      onClick={() => handleView(capture)}
                      title="View capture"
                    >
                      <i className="bi bi-eye"></i>
                    </button>
                    <button
                      className="btn btn-sm btn-danger"
                      onClick={() => handleDelete(capture.id)}
                      disabled={deleteMutation.isPending}
                      title="Delete capture"
                    >
                      {deleteMutation.isPending ? (
                        <span className="spinner-border spinner-border-sm"></span>
                      ) : (
                        <i className="bi bi-trash"></i>
                      )}
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="mt-2">
                <small className="text-muted d-block">
                  {capture.capturedAt && formatDate(capture.capturedAt)}
                </small>
                <small className="text-muted">
                  {capture.detections?.length || 0} detections
                </small>
              </div>
            </div>
          ))}
          
          {captures.length === 0 && (
            <div className="col-12 text-center py-5">
              <i className="bi bi-image display-1 text-muted mb-3"></i>
              <h6 className="text-muted">No captures yet</h6>
              <p className="text-muted small">
                Use the camera to capture images with AI detections
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}