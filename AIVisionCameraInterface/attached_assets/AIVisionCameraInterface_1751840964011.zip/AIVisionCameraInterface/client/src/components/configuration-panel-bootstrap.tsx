import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAiModel } from "@/hooks/use-ai-model";
import { useWebSocket } from "@/hooks/use-websocket";
import { apiRequest } from "@/lib/queryClient";
import type { ModelTypeOption } from "@shared/schema";

interface ConfigurationPanelProps {
  className?: string;
}

export function ConfigurationPanel({ className }: ConfigurationPanelProps) {
  const { 
    models, 
    currentConfig, 
    updateConfiguration, 
    applyConfiguration, 
    isLoading,
    modelStatus 
  } = useAiModel();
  
  const { sendMessage } = useWebSocket();
  const queryClient = useQueryClient();
  
  const [apiEndpoint, setApiEndpoint] = useState(currentConfig.apiEndpoint || '');
  const [apiKey, setApiKey] = useState(currentConfig.apiKey || '');
  const [isTestingConnection, setIsTestingConnection] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<{success: boolean; message: string} | null>(null);

  // Fetch available model types
  const { data: modelTypes = [] } = useQuery({
    queryKey: ['/api/model-types'],
  });

  const availableClasses = [
    'person', 'vehicle', 'animal', 'bicycle', 'motorcycle', 
    'bus', 'truck', 'dog', 'cat', 'bird'
  ];

  const handleConfidenceChange = (value: number) => {
    updateConfiguration({ confidence: value });
  };

  const handleIouChange = (value: number) => {
    updateConfiguration({ iouThreshold: value });
  };

  const handleMaxDetectionsChange = (value: string) => {
    updateConfiguration({ maxDetections: parseInt(value) });
  };

  const handleModelTypeChange = (modelType: string) => {
    updateConfiguration({ modelType, apiEndpoint, apiKey });
    const selectedModel = modelTypes.find((m: ModelTypeOption) => m.id === modelType);
    if (selectedModel && selectedModel.endpoint) {
      setApiEndpoint(selectedModel.endpoint);
    }
  };

  const handleClassToggle = (className: string, checked: boolean) => {
    const newEnabledClasses = checked
      ? [...currentConfig.enabledClasses, className]
      : currentConfig.enabledClasses.filter(c => c !== className);
    
    updateConfiguration({ enabledClasses: newEnabledClasses });
  };

  const testConnection = async () => {
    setIsTestingConnection(true);
    setConnectionStatus(null);
    
    try {
      const response = await fetch('/api/test-connection', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          modelType: currentConfig.modelType,
          apiEndpoint,
          apiKey
        })
      });
      
      const result = await response.json();
      setConnectionStatus(result);
    } catch (error) {
      setConnectionStatus({
        success: false,
        message: 'Failed to test connection'
      });
    } finally {
      setIsTestingConnection(false);
    }
  };

  const handleApplyConfiguration = () => {
    updateConfiguration({ apiEndpoint, apiKey });
    applyConfiguration();
  };

  const handleExportResults = async () => {
    try {
      const response = await fetch('/api/export/results');
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'ai_camera_results.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        
        // Show success notification
        const alertDiv = document.createElement('div');
        alertDiv.className = 'alert alert-success alert-dismissible fade show position-fixed top-0 end-0 m-3';
        alertDiv.style.zIndex = '9999';
        alertDiv.innerHTML = `
          <i class="bi bi-download me-2"></i>
          Results exported successfully!
          <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        document.body.appendChild(alertDiv);
        setTimeout(() => alertDiv.remove(), 3000);
      }
    } catch (error) {
      console.error('Export error:', error);
    }
  };

  const selectedModelType = modelTypes.find((m: ModelTypeOption) => m.id === currentConfig.modelType);

  return (
    <div className={`${className}`}>
      {/* AI Model Configuration */}
      <div className="card mb-4">
        <div className="card-header">
          <h5 className="card-title mb-0">AI Model Configuration</h5>
        </div>
        <div className="card-body">
          {/* Model Type Selection */}
          <div className="mb-3">
            <label className="form-label small fw-medium">Model Type</label>
            <select 
              className="form-select"
              value={currentConfig.modelType} 
              onChange={(e) => handleModelTypeChange(e.target.value)}
            >
              {modelTypes.map((model: ModelTypeOption) => (
                <option key={model.id} value={model.id}>
                  {model.name}
                </option>
              ))}
            </select>
            {selectedModelType && (
              <div className="form-text">{selectedModelType.description}</div>
            )}
          </div>

          {/* API Configuration for external services */}
          {selectedModelType?.requiresApiKey && (
            <div className="mb-3">
              <label className="form-label small fw-medium">API Endpoint</label>
              <input
                type="url"
                className="form-control"
                value={apiEndpoint}
                onChange={(e) => setApiEndpoint(e.target.value)}
                placeholder="API endpoint URL"
              />
            </div>
          )}

          {selectedModelType?.requiresApiKey && (
            <div className="mb-3">
              <label className="form-label small fw-medium">API Key</label>
              <div className="input-group">
                <input
                  type="password"
                  className="form-control"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="Enter your API key"
                />
                <button
                  className="btn btn-outline-secondary"
                  type="button"
                  onClick={testConnection}
                  disabled={isTestingConnection || !apiKey}
                >
                  {isTestingConnection ? (
                    <>
                      <span className="spinner-border spinner-border-sm me-2"></span>
                      Testing...
                    </>
                  ) : (
                    <>
                      <i className="bi bi-wifi me-1"></i>
                      Test
                    </>
                  )}
                </button>
              </div>
              {connectionStatus && (
                <div className={`alert mt-2 mb-0 ${connectionStatus.success ? 'alert-success' : 'alert-danger'}`}>
                  <i className={`bi ${connectionStatus.success ? 'bi-check-circle' : 'bi-x-circle'} me-2`}></i>
                  {connectionStatus.message}
                </div>
              )}
            </div>
          )}

          {selectedModelType?.id === 'custom_api' && (
            <div className="mb-3">
              <label className="form-label small fw-medium">Custom API Endpoint</label>
              <input
                type="url"
                className="form-control"
                value={apiEndpoint}
                onChange={(e) => setApiEndpoint(e.target.value)}
                placeholder="https://your-api.com/detect"
              />
            </div>
          )}

          {/* Confidence Threshold */}
          <div className="mb-3">
            <label className="form-label small fw-medium">
              Confidence Threshold
              <span className="badge bg-primary ms-2">{currentConfig.confidence.toFixed(2)}</span>
            </label>
            <input
              type="range"
              className="form-range"
              min="0.1"
              max="1.0"
              step="0.05"
              value={currentConfig.confidence}
              onChange={(e) => handleConfidenceChange(parseFloat(e.target.value))}
            />
            <div className="d-flex justify-content-between">
              <small className="text-muted">0.1</small>
              <small className="text-muted">1.0</small>
            </div>
          </div>

          {/* IoU Threshold */}
          <div className="mb-3">
            <label className="form-label small fw-medium">
              IoU Threshold
              <span className="badge bg-primary ms-2">{currentConfig.iouThreshold.toFixed(2)}</span>
            </label>
            <input
              type="range"
              className="form-range"
              min="0.1"
              max="0.9"
              step="0.05"
              value={currentConfig.iouThreshold}
              onChange={(e) => handleIouChange(parseFloat(e.target.value))}
            />
            <div className="d-flex justify-content-between">
              <small className="text-muted">0.1</small>
              <small className="text-muted">0.9</small>
            </div>
          </div>

          {/* Max Detections */}
          <div className="mb-3">
            <label className="form-label small fw-medium">Max Detections</label>
            <input
              type="number"
              className="form-control"
              value={currentConfig.maxDetections}
              onChange={(e) => handleMaxDetectionsChange(e.target.value)}
              min="1"
              max="100"
            />
          </div>

          {/* Class Filtering */}
          <div className="mb-3">
            <label className="form-label small fw-medium">Detect Classes</label>
            <div className="row">
              {availableClasses.map((className) => (
                <div key={className} className="col-6 col-lg-12 mb-2">
                  <div className="form-check">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id={className}
                      checked={currentConfig.enabledClasses.includes(className)}
                      onChange={(e) => handleClassToggle(className, e.target.checked)}
                    />
                    <label className="form-check-label small" htmlFor={className}>
                      {className}
                    </label>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Apply Configuration */}
          <button
            onClick={handleApplyConfiguration}
            disabled={isLoading}
            className="btn btn-primary w-100"
          >
            {isLoading ? (
              <>
                <span className="spinner-border spinner-border-sm me-2"></span>
                Applying...
              </>
            ) : (
              <>
                <i className="bi bi-check me-2"></i>
                Apply Configuration
              </>
            )}
          </button>
        </div>
      </div>

      {/* Export Options */}
      <div className="card">
        <div className="card-header">
          <h5 className="card-title mb-0">Export & Save</h5>
        </div>
        <div className="card-body">
          <div className="d-grid gap-2">
            <button
              onClick={handleExportResults}
              className="btn btn-success"
            >
              <i className="bi bi-download me-2"></i>
              Export Results (JSON)
            </button>
            
            <button
              className="btn btn-outline-secondary"
              onClick={() => {
                const configJson = JSON.stringify(currentConfig, null, 2);
                const blob = new Blob([configJson], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'ai_model_config.json';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
              }}
            >
              <i className="bi bi-save me-2"></i>
              Save Configuration
            </button>
            
            <button
              className="btn btn-outline-info"
              onClick={() => {
                const alertDiv = document.createElement('div');
                alertDiv.className = 'alert alert-info alert-dismissible fade show position-fixed top-0 end-0 m-3';
                alertDiv.style.zIndex = '9999';
                alertDiv.innerHTML = `
                  <i class="bi bi-info-circle me-2"></i>
                  Report generation feature coming soon!
                  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                `;
                document.body.appendChild(alertDiv);
                setTimeout(() => alertDiv.remove(), 3000);
              }}
            >
              <i class="bi bi-file-text me-2"></i>
              Generate Report
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}