import type { Detection } from "@shared/schema";

export class AIModelProcessor {
  private modelLoaded = false;
  private processingTime = 0;

  async loadModel(modelPath: string): Promise<void> {
    // Simulate model loading
    await new Promise(resolve => setTimeout(resolve, 1000));
    this.modelLoaded = true;
  }

  async processFrame(
    imageData: ImageData,
    config: {
      confidence: number;
      iouThreshold: number;
      maxDetections: number;
      enabledClasses: string[];
    }
  ): Promise<{ detections: Detection[]; processingTime: number }> {
    if (!this.modelLoaded) {
      throw new Error("Model not loaded");
    }

    const startTime = performance.now();
    
    // Simulate AI processing
    await new Promise(resolve => setTimeout(resolve, 20 + Math.random() * 40));
    
    const detections = this.generateDetections(config);
    
    this.processingTime = performance.now() - startTime;
    
    return {
      detections,
      processingTime: this.processingTime,
    };
  }

  private generateDetections(config: {
    confidence: number;
    iouThreshold: number;
    maxDetections: number;
    enabledClasses: string[];
  }): Detection[] {
    const allClasses = ['person', 'vehicle', 'animal', 'bicycle', 'motorcycle', 'bus', 'truck', 'dog', 'cat', 'bird'];
    const colors = ['#10b981', '#f59e0b', '#ef4444', '#3b82f6', '#8b5cf6', '#06b6d4', '#84cc16', '#f97316'];
    
    const availableClasses = allClasses.filter(cls => 
      config.enabledClasses.length === 0 || config.enabledClasses.includes(cls)
    );
    
    const numDetections = Math.min(
      Math.floor(Math.random() * config.maxDetections),
      availableClasses.length
    );
    
    const detections: Detection[] = [];
    
    for (let i = 0; i < numDetections; i++) {
      const confidence = config.confidence + (Math.random() * (1 - config.confidence));
      
      if (confidence < config.confidence) continue;
      
      const classIndex = Math.floor(Math.random() * availableClasses.length);
      const className = availableClasses[classIndex];
      
      // Generate bounding box
      const x = Math.random() * 0.7;
      const y = Math.random() * 0.7;
      const width = 0.1 + Math.random() * 0.2;
      const height = 0.1 + Math.random() * 0.2;
      
      detections.push({
        id: `det_${Date.now()}_${i}`,
        label: className,
        confidence,
        bbox: { x, y, width, height },
        color: colors[classIndex % colors.length],
      });
    }
    
    return this.applyNMS(detections, config.iouThreshold);
  }

  private applyNMS(detections: Detection[], iouThreshold: number): Detection[] {
    // Simple Non-Maximum Suppression implementation
    const sorted = detections.sort((a, b) => b.confidence - a.confidence);
    const result: Detection[] = [];
    
    for (const detection of sorted) {
      let shouldKeep = true;
      
      for (const kept of result) {
        if (this.calculateIoU(detection.bbox, kept.bbox) > iouThreshold) {
          shouldKeep = false;
          break;
        }
      }
      
      if (shouldKeep) {
        result.push(detection);
      }
    }
    
    return result;
  }

  private calculateIoU(
    box1: { x: number; y: number; width: number; height: number },
    box2: { x: number; y: number; width: number; height: number }
  ): number {
    const x1 = Math.max(box1.x, box2.x);
    const y1 = Math.max(box1.y, box2.y);
    const x2 = Math.min(box1.x + box1.width, box2.x + box2.width);
    const y2 = Math.min(box1.y + box1.height, box2.y + box2.height);
    
    if (x2 <= x1 || y2 <= y1) return 0;
    
    const intersection = (x2 - x1) * (y2 - y1);
    const union = (box1.width * box1.height) + (box2.width * box2.height) - intersection;
    
    return intersection / union;
  }

  getProcessingTime(): number {
    return this.processingTime;
  }
}
