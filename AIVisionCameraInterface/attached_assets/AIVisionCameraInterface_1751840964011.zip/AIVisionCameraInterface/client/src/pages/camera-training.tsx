import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CameraFeed } from "@/components/camera-feed";
import { ConfigurationPanel } from "@/components/configuration-panel";
import { PerformanceMetrics } from "@/components/performance-metrics";
import { RecentCaptures } from "@/components/recent-captures";
import { useTheme } from "@/components/theme-provider";
import { Camera, Settings, Moon, Sun } from "lucide-react";
import { useAiModel } from "@/hooks/use-ai-model";
import { useWebSocket } from "@/hooks/use-websocket";

export default function CameraTraining() {
  const { theme, setTheme } = useTheme();
  const { modelStatus } = useAiModel();
  const { isConnected } = useWebSocket();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Camera className="h-8 w-8 text-primary" />
              </div>
              <div className="ml-4">
                <h1 className="text-xl font-semibold">AI Camera Training</h1>
                <p className="text-sm text-muted-foreground">
                  Real-time inference & model configuration
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              {/* Model Status */}
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${modelStatus.isActive ? 'bg-success animate-pulse' : 'bg-muted'}`}></div>
                <span className="text-sm text-muted-foreground">
                  {modelStatus.isActive ? 'Model Active' : 'Model Inactive'}
                </span>
              </div>
              
              {/* WebSocket Status */}
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-success' : 'bg-error'}`}></div>
                <span className="text-sm text-muted-foreground">
                  {isConnected ? 'Connected' : 'Disconnected'}
                </span>
              </div>
              
              {/* Theme Toggle */}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setTheme(theme === "light" ? "dark" : "light")}
              >
                {theme === "light" ? (
                  <Moon className="h-4 w-4" />
                ) : (
                  <Sun className="h-4 w-4" />
                )}
              </Button>
              
              {/* Settings */}
              <Button variant="ghost" size="sm">
                <Settings className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Camera View */}
          <div className="lg:col-span-3 space-y-6">
            <CameraFeed />
            <RecentCaptures />
          </div>

          {/* Configuration Panel */}
          <div className="lg:col-span-1 space-y-6">
            <ConfigurationPanel />
            <PerformanceMetrics />
          </div>
        </div>
      </div>
    </div>
  );
}
