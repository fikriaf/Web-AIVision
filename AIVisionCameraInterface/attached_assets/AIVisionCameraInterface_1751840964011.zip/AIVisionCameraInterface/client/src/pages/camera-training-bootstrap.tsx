import { useState, useEffect } from "react";
import { CameraFeed } from "@/components/camera-feed-bootstrap";
import { ConfigurationPanel } from "@/components/configuration-panel-bootstrap";
import { PerformanceMetrics } from "@/components/performance-metrics-bootstrap";
import { RecentCaptures } from "@/components/recent-captures-bootstrap";
import { useTheme } from "@/components/theme-provider";
import { useAiModel } from "@/hooks/use-ai-model";
import { useWebSocket } from "@/hooks/use-websocket";

export default function CameraTraining() {
  const { theme, setTheme } = useTheme();
  const { modelStatus } = useAiModel();
  const { isConnected } = useWebSocket();

  useEffect(() => {
    // Set Bootstrap theme
    document.documentElement.setAttribute('data-bs-theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(theme === "light" ? "dark" : "light");
  };

  return (
    <div className="min-vh-100">
      {/* Header */}
      <nav className="navbar navbar-expand-lg bg-body-tertiary border-bottom">
        <div className="container-fluid">
          <div className="d-flex align-items-center">
            <i className="bi bi-camera text-primary fs-2 me-3"></i>
            <div>
              <h1 className="navbar-brand mb-0 fs-4 fw-bold">AI Camera Training</h1>
              <p className="text-muted small mb-0">Real-time inference & model configuration</p>
            </div>
          </div>
          
          <div className="d-flex align-items-center gap-3">
            {/* Model Status */}
            <div className="d-flex align-items-center gap-2">
              <span className={`status-indicator ${modelStatus.isActive ? 'active' : 'inactive'}`}></span>
              <small className="text-muted">
                {modelStatus.isActive ? 'Model Active' : 'Model Inactive'}
              </small>
            </div>
            
            {/* WebSocket Status */}
            <div className="d-flex align-items-center gap-2">
              <span className={`status-indicator ${isConnected ? 'active' : 'error'}`}></span>
              <small className="text-muted">
                {isConnected ? 'Connected' : 'Disconnected'}
              </small>
            </div>
            
            {/* Theme Toggle */}
            <button
              className="btn btn-outline-secondary btn-sm"
              onClick={toggleTheme}
              title="Toggle theme"
            >
              <i className={`bi ${theme === "light" ? 'bi-moon' : 'bi-sun'}`}></i>
            </button>
            
            {/* Settings */}
            <button className="btn btn-outline-secondary btn-sm" title="Settings">
              <i className="bi bi-gear"></i>
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="container-fluid py-4">
        <div className="row g-4">
          {/* Main Camera View */}
          <div className="col-lg-8">
            <div className="row g-4">
              <div className="col-12">
                <CameraFeed />
              </div>
              <div className="col-12">
                <RecentCaptures />
              </div>
            </div>
          </div>

          {/* Configuration Panel */}
          <div className="col-lg-4">
            <div className="row g-4">
              <div className="col-12">
                <ConfigurationPanel />
              </div>
              <div className="col-12">
                <PerformanceMetrics />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}